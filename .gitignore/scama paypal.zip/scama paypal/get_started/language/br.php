<?php
// connexion
$ERROR="Alguns dados informados estão incorretos. Tente novamente.";
$Email= "E-mail";
$Password = "Senha";
$dok = "Log in";
$req1 = "Obrigatório.";
$req2 = 'Obrigatório.';
$forgot ="Não consegue acessar sua conta?";
$sign = "Criar conta";
$checking = "Verificando suas informações...";
$priva = "Privacidade";
$ri8 = "Todos os direitos reservados";
$legal = "Termos e Condições";
// fin connexioon
?>