<?php
// connexion
$ERROR="Algunos de sus datos no son correctos. Inténtelo de nuevo.";
$Email= "Correo electrónico";
$Password = "Contraseña";
$dok = "Iniciar sesión";
$req1 = "El correo electrónico es obligatorio.";
$req2 = 'La contraseña es obligatoria.';
$forgot ="¿Tiene problemas para iniciar sesión?";
$sign = "Crear cuenta";
$checking = "Verificando la información…";
$priva = "Privacidad";
$ri8 = "Todos los derechos reservados";
$legal = "";
// fin connexioon
?>