<?php
// connexion
$ERROR="Überprüfen Sie Ihre Angaben und versuchen Sie es erneut.";
$Email= "E-Mail-Adresse";
$Password = "Passwort";
$dok = "Einloggen";
$req1 = "E-Mail-Adresse ist erforderlich.";
$req2 = 'Es ist ein Passwort erforderlich.';
$forgot ="Probleme beim Einloggen?";
$sign = "Neu anmelden";
$checking = "Ihre Eingaben werden überprüft…";
$priva = "Datenschutz";
$ri8 = "Alle Rechte vorbehalten";
$legal = "AGB";
// fin connexioon
?>