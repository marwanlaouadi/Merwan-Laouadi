Change your email

Config.php
get_started/configuration.php 


This sc0m clean from backdoor and malicious codes by spKINGS.party and mr exploit and finaly updated and cleaned by ebf learn